<?php
/**
 * Plugin Name: WooCommerce Music Top Seller Banner
 * Description: Adds a "Top Seller" banner to music category products
 * Version: 1.0.0
 * Requires WooCommerce: 8.0
 * WC tested up to: 8.3
 * Author: Your Name
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: woo-music-top-seller
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Main class for WooCommerce Music Top Seller Banner
 */
class WC_Music_Top_Seller {
    /**
     * Plugin version
     *
     * @var string
     */
    private $version = '1.0.0';

    /**
     * Plugin options
     *
     * @var array
     */
    private $options;

    /**
     * Constructor
     */
    public function __construct() {
        // Initialize the plugin
        add_action('plugins_loaded', array($this, 'init'));
        
        // Load options
        $this->options = get_option('wc_music_top_seller_options', array(
            'category' => 'music',
            'banner_text' => __('Top Seller', 'woo-music-top-seller')
        ));
    }

    /**
     * Initialize the plugin
     */
    public function init() {
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            return;
        }

        // Add hooks
        add_action('wp_head', array($this, 'add_styles'));
        add_action('woocommerce_before_single_product', array($this, 'display_single_product_banner'));
        add_action('woocommerce_before_shop_loop_item', array($this, 'display_loop_banner'));
        
        // Admin hooks
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            __('Top Seller Banner Settings', 'woo-music-top-seller'),
            __('Top Seller Banner', 'woo-music-top-seller'),
            'manage_woocommerce',
            'wc-music-top-seller',
            array($this, 'render_settings_page')
        );
    }

    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('wc_music_top_seller_options', 'wc_music_top_seller_options');

        add_settings_section(
            'wc_music_top_seller_main',
            __('Main Settings', 'woo-music-top-seller'),
            array($this, 'render_section_description'),
            'wc-music-top-seller'
        );

        add_settings_field(
            'category',
            __('Product Category', 'woo-music-top-seller'),
            array($this, 'render_category_field'),
            'wc-music-top-seller',
            'wc_music_top_seller_main'
        );

        add_settings_field(
            'banner_text',
            __('Banner Text', 'woo-music-top-seller'),
            array($this, 'render_banner_text_field'),
            'wc-music-top-seller',
            'wc_music_top_seller_main'
        );
    }

    /**
     * Render section description
     */
    public function render_section_description() {
        echo '<p>' . esc_html__('Configure the Top Seller Banner settings below.', 'woo-music-top-seller') . '</p>';
    }

    /**
     * Render category field
     */
    public function render_category_field() {
        $categories = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        ));

        if (is_wp_error($categories)) {
            echo '<p class="error">' . esc_html__('Error loading categories.', 'woo-music-top-seller') . '</p>';
            return;
        }

        echo '<select name="wc_music_top_seller_options[category]">';
        foreach ($categories as $category) {
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr($category->slug),
                selected($this->options['category'], $category->slug, false),
                esc_html($category->name)
            );
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__('Select the product category to display the Top Seller banner.', 'woo-music-top-seller') . '</p>';
    }

    /**
     * Render banner text field
     */
    public function render_banner_text_field() {
        printf(
            '<input type="text" name="wc_music_top_seller_options[banner_text]" value="%s" class="regular-text" />',
            esc_attr($this->options['banner_text'])
        );
        echo '<p class="description">' . esc_html__('Enter the text to display in the Top Seller banner.', 'woo-music-top-seller') . '</p>';
    }

    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('wc_music_top_seller_options');
                do_settings_sections('wc-music-top-seller');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    /**
     * Display WooCommerce missing notice
     */
    public function woocommerce_missing_notice() {
        ?>
        <div class="error">
            <p><?php esc_html_e('WooCommerce Music Top Seller Banner requires WooCommerce to be installed and active.', 'woo-music-top-seller'); ?></p>
        </div>
        <?php
    }

    /**
     * Add custom styles
     */
    public function add_styles() {
        ?>
        <style>
            .music-top-seller-banner {
                background-color: #2c3338;
                color: #ffffff;
                text-align: center;
                padding: 8px;
                font-size: 14px;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                margin-bottom: 20px;
                position: relative;
            }
            .music-top-seller-banner::before {
                content: "★";
                margin-right: 8px;
                color: #ffd700;
            }
            @media (max-width: 768px) {
                .music-top-seller-banner {
                    font-size: 12px;
                    padding: 6px;
                }
            }
        </style>
        <?php
    }

    /**
     * Check if product is in selected category
     *
     * @param int $product_id Product ID
     * @return bool
     */
    private function is_music_product($product_id) {
        $cache_key = 'music_product_' . $product_id;
        $is_music = wp_cache_get($cache_key);

        if (false === $is_music) {
            $is_music = has_term($this->options['category'], 'product_cat', $product_id);
            wp_cache_set($cache_key, $is_music, '', 3600); // Cache for 1 hour
        }

        return $is_music;
    }

    /**
     * Display banner on single product page
     */
    public function display_single_product_banner() {
        global $product;
        
        if (!$product || !$this->is_music_product($product->get_id())) {
            return;
        }

        echo '<div class="music-top-seller-banner">' . esc_html($this->options['banner_text']) . '</div>';
    }

    /**
     * Display banner in product loop
     */
    public function display_loop_banner() {
        global $product;
        
        if (!$product || !$this->is_music_product($product->get_id())) {
            return;
        }

        echo '<div class="music-top-seller-banner">' . esc_html($this->options['banner_text']) . '</div>';
    }
}

// Initialize the plugin
new WC_Music_Top_Seller(); 